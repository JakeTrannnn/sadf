public class Balloon {
        private double radius;

    /**
     * makes radius equal 0
     */
    public Balloon() {
            radius = 0;
        }

        /**
         * adds amount to the radius
         * @param amount the amount to be inflated
         */
        public void inflate(double amount){
            radius += amount;
        }

        /**
         * returns the volume of the balloon
         * @return the volume of the balloon
         */
        public double getVolume(){
            return Math.PI*radius*radius*radius*4/3;
        }
        
        /**
        * returns the radius
        * @return the radius
        */
        public double getRadius(){
        return radius;
        }
}
