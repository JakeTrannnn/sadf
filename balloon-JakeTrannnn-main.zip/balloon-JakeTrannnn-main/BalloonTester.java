import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class BalloonTest{
    public static void main(String args[]){
        Balloon balloon = new Balloon();
        balloon.inflate(5);
        System.out.println(balloon.getVolume());
        balloon.inflate(5);
        System.out.println(balloon.getVolume());
    }

    @Test
    public void testVolume(){
        Balloon balloon = new Balloon();
        balloon.inflate(10);
        Assertions.assertEquals(4188.790204786391, balloon.getVolume());
    }

    @Test
    public void testInflate(){
        Balloon balloon = new Balloon();
        balloon.inflate(10);
        Assertions.assertEquals(10, balloon.getRadius());
    }
    @Test
    public void testRadius(){
        Balloon balloon = new Balloon();
        balloon.inflate(10);
        Assertions.assertEquals(10, balloon.getRadius());
    }
}
